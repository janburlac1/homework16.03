public class Main {
    public static void main(String[] args) {
        byte b = 1;
        short c = b;
        int d = c;
        long e = d;
        double f = e;
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);
        System.out.println(e);
        System.out.println(f);

    }
}