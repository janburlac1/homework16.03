public class Main {
    public static void main(String[] args) {
        String mystring = ("I study Basic Java");
        System.out.println(mystring.charAt(0));;
        System.out.println(mystring.charAt(mystring.length()-1));
        System.out.println(mystring.contains("Java"));
        System.out.println(mystring.replace('a', 'o'));
        System.out.println(mystring.toUpperCase());
        System.out.println(mystring.toLowerCase());
        System.out.println(mystring.substring(14,18));
    }
}