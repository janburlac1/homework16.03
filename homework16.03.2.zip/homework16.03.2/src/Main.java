public class Main {
    public static void main(String[] args) {
      long lo = 1000L;
      byte by = (byte) lo;
      short sh = by;
      int in = sh;
        System.out.println(lo);
        System.out.println(by);
        System.out.println(sh);
        System.out.println(in);




    }
}